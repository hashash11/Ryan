import { Matrix4 } from "@math.gl/core";

export interface TileRenderInfo {
    offset: number,
    size: number,
    width: number,
    height: number,
    vertices: number[],
    textureQuad: number[],
    mvpMat: Matrix4
}

export interface MercatorTileRenderRequest {
    width: number;
    height: number;
    id: number;
    draw: boolean;
    // @ts-ignore # this was removed from libdom because its "experimental" but is fully supported in chrome
    canvas: OffscreenCanvas;
    imageData: Uint8Array;
    tileRenderInfo: TileRenderInfo[];
}