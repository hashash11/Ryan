import * as UPNG from 'upng-js';


export class BufferedImage {

    public imageData: Uint8Array;
    public width: number;
    public height: number;
    public depth: number;
    public ctype: UPNG.ctype;

    public static cloneWithNewBuffer(im: BufferedImage, bufferData: Uint8Array): BufferedImage {
        return new BufferedImage(null, bufferData, im.width, im.height, im.depth, im.ctype);
    }
    
    constructor(png: any, imageData?: Uint8Array, width?: number, height?: number, depth?: number, ctype?: UPNG.ctype) {
        if(png) {
            var decoded = UPNG.decode(png)
            this.imageData = decoded.data;
            this.width = decoded.width;
            this.height = decoded.height;
            this.depth = decoded.depth;
            this.ctype = decoded.ctype;
        } else if (!png && imageData && width && height && depth && ctype!=undefined) {
            this.imageData = imageData;
            this.width = width;
            this.height = height;
            this.depth = depth;
            this.ctype = ctype;
        } else {
            console.warn("Creating buffered image with no data");
            this.imageData = new Uint8Array();
            this.width = 0;
            this.height = 0;
            this.depth = 0;
            this.ctype = 0;
        }
    }


    public getRaster() : any {
        return null;
    }

    public setData(data : any) {
        this.imageData = data
    }
}