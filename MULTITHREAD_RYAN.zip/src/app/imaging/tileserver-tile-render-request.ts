import { TileRef } from "../tileserver-client/tile-ref";
import { BufferedImage } from "./buffered-image";

export interface TileserverTileRenderRequest{

    tileRef: TileRef,
    bufferedImage: BufferedImage;

}