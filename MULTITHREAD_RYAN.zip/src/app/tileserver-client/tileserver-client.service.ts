import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TilePyramidDescriptor } from './tile-pyramid-descriptor';
import { TileRef } from './tile-ref';

@Injectable({
  providedIn: 'root'
})
export class TileserverClient {

  private tileserverUrl = 'https://tileserver.leidoslabs.com';
  private apiKey = 'sAWFuNz3RmanpIhHazTdo8hwT7bKhWPAa5MYcBbX'

  constructor(private http: HttpClient) { }

  getMetadata(name: string, timestamp: string): Observable<TilePyramidDescriptor> {
    var metadata_url = `${this.tileserverUrl}/tileserver/${name}/${timestamp}/metadata.json`
    return this.http.get<TilePyramidDescriptor>(metadata_url, { headers: { 'x-api-key': this.apiKey } })
  }

  getTile(tileRef: TileRef): Observable<ArrayBuffer> {
    var tile_url = `${this.tileserverUrl}/tileserver/${tileRef.getTileserverPath()}.png`
    return this.http.get(tile_url, {
        responseType: "arraybuffer", 
        headers: { 'x-api-key': this.apiKey}});
  }  

}