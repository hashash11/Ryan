import { Injectable } from '@angular/core';
import { NgxIndexedDBService } from 'ngx-indexed-db';
import { catchError, map, Observable, throwError } from 'rxjs';
import { BufferedImage } from '../imaging/buffered-image';
import { TileRef } from './tile-ref';
import { TileserverClient } from './tileserver-client.service';


export interface CachedTile {
    tileKey: string;
    imageData: BufferedImage;
}


@Injectable({
    providedIn: 'root'
  })
export class TileCacheService {

    constructor(private tileServerClient: TileserverClient, private dbService: NgxIndexedDBService) {

    }

    getTile(tileRef: TileRef): Observable<BufferedImage> {
        
        return (<Observable<CachedTile>> this.dbService.getByIndex("imagery", "tileKey", tileRef.getCacheKey())).pipe(
            map((result) => {
                     if(!result) {
                         throw new Error('Not found in cache')
                     } else {
                        console.log("Got a tile from the cache!")
                         return result;
                     }
                }
            ),
            catchError((err, caught) => {
                // not found in cache                
                return this.tileServerClient.getTile(tileRef).pipe(                    
                    map(response => {
                        return new BufferedImage(response);
                    }),
                    map(image => {
                        var cachedTile: CachedTile = {
                            tileKey: tileRef.getCacheKey(),
                            imageData: image
                        }                        
                        this.dbService.add("imagery", cachedTile).subscribe((key) => {
                            console.log('key: ', key);
                          });
                        return cachedTile;
                    })
                )
            }),
            map((cachedTile) => cachedTile.imageData)
        )
    }
}