import { Point2D } from "./warp";

export class ImageScale {


    private scaleX: number;
    private scaleY: number;

    constructor(scaleX: number, scaleY: number) {
        this.scaleX = scaleX;
        this.scaleY = scaleY;
    }

    scaleUpToR0(point: Point2D): Point2D {
        var rsetFactorX = Math.pow(2.0, this.getRsetForScaleX());
        var rsetFactorY = Math.pow(2.0, this.getRsetForScaleY());
        return new Point2D(rsetFactorX * point.getX(), rsetFactorY * point.getY());
    }

    scaleDownToRset(point: Point2D): Point2D {
        var rsetFactorX = Math.pow(0.5, this.getRsetForScaleX());
        var rsetFactorY = Math.pow(0.5, this.getRsetForScaleY());
        return new Point2D(rsetFactorX * point.x, rsetFactorY * point.y);
    }

    setScale(scaleX: number, scaleY: number): void {
        this.scaleX = scaleX;
        this.scaleY = scaleY;
    }

    mul(scaleX: number, scaleY: number): ImageScale {        
        this.setScale(this.scaleX*scaleX, this.scaleY*scaleY);
        return this
    }
    
    getRsetForScaleX(): number {
        return ImageScale.getRsetForScale(this.scaleX);
    }
    
    getRsetForScaleY(): number {
        return ImageScale.getRsetForScale(this.scaleY);
    }

    getImageRset(maxRset: number): number {
        var xRset = this.getRsetForScaleX();
        var yRset = this.getRsetForScaleY();
        return Math.min(Math.max(0.0, Math.min(xRset, yRset)), maxRset);
    }

    getRset(): number {
        return Math.min(this.getRsetForScaleX(), this.getRsetForScaleY());
    }

    setRset(rset: number): void {
        var scaleForRset = ImageScale.getScaleForRset(rset);
        this.setScale(scaleForRset, scaleForRset)
    }

    within(minScale: ImageScale, maxScale: ImageScale): boolean {
        return this.scaleX >= minScale.scaleX && this.scaleY >= minScale.scaleY &&
            this.scaleX <= maxScale.scaleX && this.scaleY <= maxScale.scaleY;
    }

    static forRset(rset: number): ImageScale {
        var imageScale = new ImageScale(1.0,1.0)
        imageScale.setRset(rset)
        return imageScale
    }

    // scale in range [0., 1.]
    static getRsetForScale(scale: number): number {
        return -1. * Math.log2(scale)
    }

    static getScaleForRset(rset: number): number {
        return Math.pow(0.5, rset);
    }


}