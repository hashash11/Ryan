import { Matrix3 } from "@math.gl/core";
import { flatten, lusolve } from "mathjs";

export class PerspectiveTransform {

    // public static getQuadToQuad(srcPts: number[], dstPts: number[]): Matrix3 {
  
    //   /* dstPts = [-100,0,
    //    100,0,
    //    100,100,
    //    -200,200
    //  ]*/
  
    //   // Everything from here was based off of this: https://math.stackexchange.com/questions/296794/finding-the-transform-matrix-from-4-projected-points-with-javascript
    //   let matAlpha = [[srcPts[0], srcPts[2], srcPts[4]],
    //                   [srcPts[1], srcPts[3], srcPts[5]],
    //                   [        1,         1,        1]];

    //   let vecAlpha = [srcPts[6], srcPts[7], 1];
  
    //   let coeffs1: number[] = []
    //   try {
    //     let myAnswer = lusolve(matAlpha, vecAlpha);
    //     coeffs1 = flatten(lusolve(matAlpha, vecAlpha)) as number[];
    //   }
    //   catch (e) {
    //     console.log(e);
    //   }
  
    //   let A = new Matrix3([coeffs1[0] * srcPts[0], coeffs1[1] * srcPts[2], coeffs1[2] * srcPts[4],
    //   coeffs1[0] * srcPts[1], coeffs1[1] * srcPts[3], coeffs1[2] * srcPts[5],
    //   coeffs1[0], coeffs1[1], coeffs1[2]]).transpose();
  
    //   let matBeta = [[dstPts[0], dstPts[2], dstPts[4]],
    //   [dstPts[1], dstPts[3], dstPts[5]],
    //   [1, 1, 1]];
    //   let vecBeta = [dstPts[6], dstPts[7], 1];
  
    //   var coeffs2: number[] = [];
    //   try {
    //     coeffs2 = flatten(lusolve(matBeta, vecBeta)) as number[];
    //   } catch (e) {
  
    //     console.log(e);
    //   }
  
    //   let B = new Matrix3([coeffs2[0] * dstPts[0], coeffs2[1] * dstPts[2], coeffs2[2] * dstPts[4],
    //   coeffs2[0] * dstPts[1], coeffs2[1] * dstPts[3], coeffs2[2] * dstPts[5],
    //   coeffs2[0], coeffs2[1], coeffs2[2]]).transpose();
  
    //   let Acopy = new Matrix3();
    //   let Bcopy = new Matrix3();
  
    //   Acopy.copy(A);
    //   Bcopy.copy(B);
    //   Acopy.invert()
    //   let C = Bcopy.multiplyRight(Acopy);
  
    //   // console.log("testing my mats");
    //   // console.log((new Matrix3()).copy(C).multiplyRight([1,1,1]));
  
    //   return C; 
  
  
    // }

    public static getQuadToQuad(srcPts: number[], dstPts: number[]): Matrix3 {
      var tx1 = new Matrix3();
      var tx2 = new Matrix3()
      PerspectiveTransform.quadToSquare(srcPts[0],srcPts[1],srcPts[2],srcPts[3],srcPts[4],srcPts[5],srcPts[6],srcPts[7], tx1);
      PerspectiveTransform.squareToQuad(dstPts[0],dstPts[1],dstPts[2],dstPts[3],dstPts[4],dstPts[5],dstPts[6],dstPts[7], tx2);
      return PerspectiveTransform.concatenate(tx1, tx2);
    }

    private static concatenate(tx1: Matrix3, tx2: Matrix3): Matrix3 {

      var res: Matrix3 = new Matrix3();
      
      var m00p = tx1[0] * tx2[0] + tx1[1] * tx2[3] + tx1[2] * tx2[6];
      var m10p = tx1[0] * tx2[1] + tx1[1] * tx2[4] + tx1[2] * tx2[7];
      var m20p = tx1[0] * tx2[2] + tx1[1] * tx2[5] + tx1[2] * tx2[8];
      var m01p = tx1[3] * tx2[0] + tx1[4] * tx2[3] + tx1[5] * tx2[6];
      var m11p = tx1[3] * tx2[1] + tx1[4] * tx2[4] + tx1[5] * tx2[7];
      var m21p = tx1[3] * tx2[2] + tx1[4] * tx2[5] + tx1[5] * tx2[8];
      var m02p = tx1[6] * tx2[0] + tx1[7] * tx2[3] + tx1[8] * tx2[6];
      var m12p = tx1[6] * tx2[1] + tx1[7] * tx2[4] + tx1[8] * tx2[7];
      var m22p = tx1[6] * tx2[2] + tx1[7] * tx2[5] + tx1[8] * tx2[8];
      res[0] = m00p;
      res[1] = m10p;
      res[2] = m20p;
      res[3] = m01p;
      res[4] = m11p;
      res[5] = m21p;
      res[6] = m02p;
      res[7] = m12p;
      res[8] = m22p;

      return res;
    }

    private static squareToQuad(x0: number, y0: number, x1: number, y1: number, x2: number, y2: number, x3: number, y3: number, tx: Matrix3) {      
      var dx3 = x0 - x1 + x2 - x3;
      var dy3 = y0 - y1 + y2 - y3;
      tx[8] = 1.0;
      var eps = 1e-6
      if (Math.abs(dx3) < eps && Math.abs(dy3) < eps) {
        tx[0] = x1 - x0;
        tx[3] = x2 - x1;
        tx[6] = x0;
        tx[1] = y1 - y0;
        tx[4] = y2 - y1;
        tx[7] = y0;
        tx[2] = 0.0;
        tx[5] = 0.0;
      } else {
        var dx1 = x1 - x2;
        var dy1 = y1 - y2;
        var dx2 = x3 - x2;
        var dy2 = y3 - y2;
        var invdet = 1.0 / (dx1 * dy2 - dx2 * dy1);
        tx[2] = (dx3 * dy2 - dx2 * dy3) * invdet;
        tx[5] = (dx1 * dy3 - dx3 * dy1) * invdet;
        tx[0] = x1 - x0 + tx[2] * x1;
        tx[3] = x3 - x0 + tx[5] * x3;
        tx[6] = x0;
        tx[1] = y1 - y0 + tx[2] * y1;
        tx[4] = y3 - y0 + tx[5] * y3;
        tx[7] = y0;
      }
    }

    private static makeAdjoint(mat: Matrix3) {
      var m00p = mat[4] * mat[8] - mat[7] * mat[5];
      var m01p = mat[7] * mat[2] - mat[1] * mat[8];
      var m02p = mat[1] * mat[5] - mat[4] * mat[2];
      var m10p = mat[6] * mat[5] - mat[3] * mat[8];
      var m11p = mat[0] * mat[8] - mat[6] * mat[2];
      var m12p = mat[3] * mat[2] - mat[0] * mat[5];
      var m20p = mat[3] * mat[7] - mat[6] * mat[4];
      var m21p = mat[6] * mat[1] - mat[0] * mat[7];
      var m22p = mat[0] * mat[4] - mat[3] * mat[1];
      mat[0] = m00p;
      mat[1] = m01p;
      mat[2] = m02p;
      mat[3] = m10p;
      mat[4] = m11p;
      mat[5] = m12p;
      mat[6] = m20p;
      mat[7] = m21p;
      mat[8] = m22p;
    }

    private static quadToSquare(x0: number, y0: number, x1: number, y1: number, x2: number, y2: number, x3: number, y3: number, tx: Matrix3) {
      PerspectiveTransform.squareToQuad(x0,y0,x1,y1,x2,y2,x3,y3,tx);
      PerspectiveTransform.makeAdjoint(tx);
    }
  }