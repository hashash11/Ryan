import { TileServerImage } from "./tileserver-image";

export class TileRef {
    public collectionId: string;
    public timestamp: string;
    public x: number;
    public y: number;
    public rSet: number;
    public band: number;

    constructor(collectionId: string, timestamp: string, x: number, y: number, rSet: number, band: number) {
        this.collectionId = collectionId;
        this.timestamp = timestamp;
        this.x = x;
        this.y = y;
        this.rSet = rSet;
        this.band = band;
    }

    getForBand(band: number): TileRef {
        return new TileRef(this.collectionId, this.timestamp, this.x, this.y, this.rSet, band);
    }

    getImageName(): string {
        return this.collectionId + ":" + this.timestamp;
    }

    getCacheKey(): string {
        return this.getImageName + ":" + this.x + ":" + this.y + ":" + this.rSet + ":" + this.band
    }
}