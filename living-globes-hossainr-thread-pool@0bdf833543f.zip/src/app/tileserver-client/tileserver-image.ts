import { lastValueFrom, Observable } from "rxjs";
import { CameraModel, FourCornerBasedCameraModel } from "../photogrammetry/app.cameramodel";
import { TilePyramidDescriptor } from "./tile-pyramid-descriptor";
import { TileRef } from "./tile-ref";
import { TileCacheService } from "./tile-cache.service";
import { TileserverClient } from "./tileserver-client.service";
import { BufferedImage } from "../imaging/buffered-image";

export class TileServerImage {
  private _collectionId: string;
  private _timestamp: string;
  private _tilePyramidDescriptor?: TilePyramidDescriptor;
  private _cameraModel?: CameraModel;

  constructor(collectionId: string, timestamp: string, private tileServerClient: TileserverClient, private cacheService: TileCacheService) {
    this._collectionId = collectionId;
    this._timestamp = timestamp;
  }

  public get collectionId(): string {
    return this._collectionId;
  }
  
  public get timestamp(): string {
    return this._timestamp;
  }

  async getTilePyramidDescriptor(): Promise<TilePyramidDescriptor> {
    if (!this._tilePyramidDescriptor) {
      this._tilePyramidDescriptor = await lastValueFrom(this.tileServerClient.getMetadata(this._collectionId, this._timestamp))
    }
    return this._tilePyramidDescriptor;
  }

  async getNumBands(): Promise<number> {
    return (await this.getTilePyramidDescriptor()).metadata['NBANDS']
  }

  // async getCameraModel(): Promise<CameraModel> {
  //   if (!this._cameraModel) {
  //     var descriptor: TilePyramidDescriptor = await this.getTilePyramidDescriptor();
  //     this._cameraModel = new FourCornerBasedCameraModel(
  //       descriptor.width,
  //       descriptor.height,
  //       descriptor.bounds.geometry.coordinates[0],
  //       descriptor.bounds.geometry.coordinates[0][0]
  //     )
  //   }
  //   return this._cameraModel;
  // }

  getTileserverTile(tileRef: TileRef): Observable<BufferedImage> {    
    return this.getTileserverTileForBand(tileRef.getForBand(0))
    // var numBands: number = await this.getNumBands();
    // var bufferedImageBands: BufferedImage[] = [];

    // for (var i = 0; i < numBands; i++) {
    //   bufferedImageBands.push(this.getTileserverTileForBand(tileRef.getForBand(i)))
    // }

    // if (numBands > 0 && numBands < 3) {
    //   return this.mergeBands([bufferedImageBands[0], bufferedImageBands[0], bufferedImageBands[0]])
    // } else {
    //   return this.mergeBands([bufferedImageBands[0], bufferedImageBands[1], bufferedImageBands[2]])
    // }

  }

  private getTileserverTileForBand(tileRef: TileRef): Observable<BufferedImage> {
    return this.cacheService.getTile(tileRef);
  }

  private mergeBands(bands: BufferedImage[]): BufferedImage {
    // TODO: actually merge the bands, obviously
    return bands[0];

  }

}