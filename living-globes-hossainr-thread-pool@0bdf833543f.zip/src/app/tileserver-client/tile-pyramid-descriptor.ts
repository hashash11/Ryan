interface ImageryEssentialMetadata {
    NROWS: number;
    NCOLS: number;
    NBANDS: number;
}

interface ImageryMetadata {
    [key : string]: any | ImageryEssentialMetadata;
}

export interface TilePyramidDescriptor {
    edhIdentifier: string;
    name: string;
    metadata: ImageryMetadata,
    tileWidth: number,
    tileHeight: number,
    width: number,
    height: number,
    minrlevel: number,
    maxRLevel: number,
    boundingBox: number[],
    bounds: any // TODO replace with geojson type when it gets merged
}