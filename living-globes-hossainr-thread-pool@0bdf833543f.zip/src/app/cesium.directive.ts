import { Directive, ElementRef, OnInit } from '@angular/core';
import {
  OpenStreetMapImageryProvider, Viewer, WebMapTileServiceImageryProvider,
  Rectangle, Request, WebMercatorTilingScheme, Math
} from 'cesium';
import { ImageGeneratorService } from './imaging/image-generator.service';
import Catalog from './catalog/catalog';
import { bboxPolygon, Feature, Polygon, Properties } from '@turf/turf';

// https://cesium.com/blog/2018/03/12/cesium-and-angular/ for instructions on running cesium in an angular project
@Directive({
  selector: '[app-cesium]'
})
export class CesiumDirective implements OnInit {

  constructor(private imageGenerator: ImageGeneratorService, private el: ElementRef) { }

  ngOnInit(): void {

    // Init Catalog
    Catalog.getCatalog();

    // Use our in-house open street maps server
    var osm = new OpenStreetMapImageryProvider({
      url: 'https://osm.leidoslabs.com/'
    })
    const viewer = new Viewer(this.el.nativeElement,
      {
        //Hide the base layer picker
        baseLayerPicker: false,
        // Default geocoder uses ion, so turn it off
        geocoder: false,
        //Use OpenStreetMaps
        imageryProvider: osm
      }
    );

    // Show FPS rates
    viewer.scene.debugShowFramesPerSecond = true;

    // Hide our implementation in a WMTS provider. Cesium requests a tile, we fulfill that request with a WebGL canvas and the tileserver
    class WebGLmageProvider extends WebMapTileServiceImageryProvider {

      // Object that can turn x,y,z of tiles into a latitude and longitude
      private tileConverter = new WebMercatorTilingScheme()

      constructor(private imageGenerator: ImageGeneratorService) {
        super({ url: '', layer: '', style: '', format: '', tileMatrixSetID: '' })
      }

      override requestImage(x: number, y: number, level: number, request?: Request): Promise<any> | undefined {
        var rectangle: Rectangle = this.tileConverter.tileXYToRectangle(x, y, level)
        var west:  number = Math.toDegrees(rectangle.west)
        var south: number = Math.toDegrees(rectangle.south)
        var east:  number = Math.toDegrees(rectangle.east)
        var north: number = Math.toDegrees(rectangle.north)

        const tileBboxPoly: Feature<Polygon, Properties> = bboxPolygon([west, south, east, north]);
        const collection = Catalog.intersectingImagesCollection(tileBboxPoly);

        return this.imageGenerator.getImage(collection)

      }
    }

    // We are not really using a WMTS server even though we extend it, we just like the way it requests tiles because its an easy format
    // to work with. This demo also hardcodes the layer/url so that you can see it all in one block, so we ignore all these constructor options
    const provider = new WebGLmageProvider(this.imageGenerator)


    // By default, cesium adds a layer on top of all the other layers. You can explicitly set the ordering as well though
    viewer.imageryLayers.addImageryProvider(provider);

  }

}