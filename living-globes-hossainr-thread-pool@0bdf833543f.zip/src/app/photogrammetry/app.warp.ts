export class Point{
  public x:number;
  public y:number;
   
  constructor(x:number,y:number){
      this.x=x;
      this.y=y;
  }

  public getX():number {
      return this.x;
  }
  public getY():number {
      return this.y;
  }

  public setX(x:number):void {
      this.x = x;
  }

  public setY(y:number):void {
      this.y = y;
  }

 
  /**
   * Returns the distance from this <code>Point2D</code> to a
   * specified <code>Point2D</code>.
   *
   * @param pt the specified point to be measured
   *           against this <code>Point2D</code>
   * @return the distance between this <code>Point2D</code> and
   * the specified <code>Point2D</code>.
   * @since 1.2
   */
  
       public distance(pt:Point):number {
          let px:number = pt.getX() - this.getX();
          let py:number = pt.getY() - this.getY();
          return Math.sqrt(px * px + py * py);
      }
}


/**
 * This class provides static methods to manipulate matricies,
 * including solving sets of linear equations.
 */
 export class Matrix
 {
   private static readonly TINY:number = Number.MIN_VALUE;
 
 
   /**
    *  LU decomposition of a matrix
    *
    *  Use this in conjunction with backSubstituteLU() to solve linear
    *  equations or invert a matrix.  For example, to solve the linear
    *  set of equations
    *    A x  =  b
    *  do the following:
    *    int   n, indx[];
    *    double a[][], b[], d;
    *      .   .
    *      .   .
    *    a=...;
    *    b=...;
    *    indx=...;
    *      .   .
    *      .   .
    *    d = decomposeLU(a, n, indx);
    *    backSubstituteLU(a, n, indx, b);
    *
    *  Code description:
    *    Given the n x n matrix a[1..n][1..n], replace it by its LU
    *    decomposition.  The output is placed in a.  The vector indx[1..n]
    *    records the row permutation effected by the partial pivoting.
    *    d (return value) is +1 or -1 depending on whether the number of row
    *    interchanges was even or odd.
    *
    */
   public static decomposeLU(a:number[][],  n:number,  indx:number[]):number
   {
     var       i:number;
     let imax:number=0;
     var j:number, k:number;
     var big:number, dum:number, sum:number, temp:number, d:number;
     var  vv:number[];
 
     vv = new Array(n);
     d = 1.0;
                                 // loop over rows to get implicit scaling info
     for(i=0; i<n; i++)
     {
       big = 0.0;
       for(j=0; j<n; j++)  if((temp=Math.abs(a[i][j])) > big)  big = temp;
                                 // check for nonzero largest element
                                 // geo.ExcpSingularMatrix = singular matrix in Matrix.decomposeLU()
       if (big==0.0)
       {
         throw new Error("SingularExcp");
       }
        vv[i] = 1.0/big;          // save the scaling
     } // endfor i
 
                                 // loop over columns (Crout's method)
     for(j=0; j<n; j++) {
       for(i=0; i<j; i++) {
         sum = a[i][j];
         for(k=0; k<i; k++) sum -= a[i][k]*a[k][j];
         a[i][j] = sum;
       } // endfor i
                                 // initialize search for largest pivot element
       big = 0.0;
       for(i=j; i<n; i++) {
         sum = a[i][j];
         for(k=0; k<j; k++)  sum -= a[i][k]*a[k][j];
         a[i][j] = sum;
         if((dum=vv[i]*Math.abs(sum)) >= big) {
           big = dum;
           imax = i;
         } // endif
       } // endfor i
                                 // need to interchange rows
       if(j != imax) {
         for(k=0; k<n; k++) {
           dum=a[imax][k];
           a[imax][k] = a[j][k];
           a[j][k] = dum;
         } // endfor k
                                 // interchange parity of d
         d = -d;
         vv[imax] = vv[j];
       } // endif
 
       indx[j] = imax;
       if(a[j][j] == 0)  a[j][j] = this.TINY;
                                 // divide by pivot element
       if(j != (n-1)) {
         dum = 1.0/a[j][j];
         for(i=j+1; i<n; i++)  a[i][j] *= dum;
       } // endif
 
     } // endfor j -  go back for the next column
 
     return d;
   } // end decomposeLU()
 
   /*
    *  Forward substitution and back substitution on an LU decomposed matrix.
    *  Use this in conjunction with function decomposeLU to solve linear systems
    *  or invert a matrix.
    *
    */
   public static backSubstituteLU(a:number[][], n:number, indx:number[], b:number[]):void
   {
     var    i:number;
     let ii:number=-1;
     var ip:number, j:number;
     var sum:number;
                                 // forward substitution
     for(i=0; i<n; i++) {
       ip = indx[i];
       sum = b[ip];
       b[ip] = b[i];
       if(ii != -1)
       {
         for(j=ii; j<=i - 1; j++)  sum -= a[i][j]*b[j];
       }
       else if(sum != 0.0)
       {
         ii = i;
       } // endif
       b[i] = sum;
     } // endfor i
 
                                 // back substitution
     for(i=n-1; i>=0; i--) {
       sum = b[i];
       for(j=i + 1; j<n; j++)
         sum -= a[i][j]*b[j];
                                 // store a component of the solution vector x
       b[i] = sum/a[i][i];
     } // endfor i
 
   } // end backSubstituteLU()
 
 
   // add other matrix manipulation methods here as needed
 
 
 } // end Matrix






/**
 * This class encapsulates the data that form a set of warp coefficients.
 */
 export class WarpCoefficientSet
 {
   private       myDegree:number;    // the degree of the polynomial
   private       myNumberOfCoeffs:number;  // num of coeffs = (deg+1)*(deg+2)/2
   private  myA:number[];         // first (f1) set of coefficients (a's)
   private  myB:number[];         // second (f2) set of coefficients (b's)
   private  myErrors:number[];    // errors for each point
   private    myChisqr:number;   // chi squared error
 
   private    myNumTiePts; // num tie pts (length of myErrors)
   private    myMaxErr;    // the maximum error over all tie points
 
     /**
      * Constructor
      * @param degree the degree of the polynomial
      * @param numberOfCoeffs num of coeffs = (deg+1)*(deg+2)/2
      * @param numTiePts num tie pts (length of myErrors)
      * @param a first (f1) set of coefficients (a's)
      * @param b second (f2) set of coefficients (b's)
      * @param errors errors for each point
      * @param chisqr chi squared error
      */
   public constructor( degree:number,  numberOfCoeffs:number,  numTiePts:number,
      a:number[],   b:number[],  errors:number[], chisqr:number)
   {
     this.myDegree = degree;
     this.myNumberOfCoeffs = numberOfCoeffs;
     this.myA = a;
     this.myB = b;
     this.myErrors = errors;
     this.myChisqr = chisqr;
 
     // MDP: added 03/31/04
     this.myMaxErr = 0;
     for (let i=0; i<numTiePts; i++)  {
       if (this.myMaxErr < errors[i]) this.myMaxErr = errors[i];
     }
     this.myNumTiePts = numTiePts;
 
   }
 
     /**
      * @return the degree of the polynomial
      */
   public getDegree():number
   {
     return this.myDegree;
   }
 
     /**
      * @return num of coeffs = (deg+1)*(deg+2)/2
      */
   public  getNumberOfCoeffs():number
   {
     return this.myNumberOfCoeffs;
   }
 
     /**
      * @return first (f1) set of coefficients (a's)
      */
   public getACoeffs():number[]
   {
     return this.myA;
   }
 
     /**
      * @return second (f2) set of coefficients (b's)
      */
   public  getBCoeffs():number[] {
       return this.myB;
   }
 
     /**
      * @return errors for each point
      */
   public  getErrors():number[]
   {
     return this.myErrors;
   }
 
     /**
      * @return chi squared error
      */
   public getChisqr():number
   {
     return this.myChisqr;
   }
 
     /**
      * @return the maximum error over all tie points
      */
   public getMaxErr():number
   {
     return this.myMaxErr;
   }
 
     /**
      * @return num tie pts (length of myErrors)
      */
   public getNumTiePts():number
   {
     return this.myNumTiePts;
   }
 
 }
 


/**
 * This class encapsulates the data that form a tie point pair.
 * This is the source image coordinate (x1, y1) in one image and
 * the source image coordinate (x2, y2) of the same point on the ground
 * in a second image.
 */
 export class TiePointPair
 {
   private myPointInFirstImage:Point;
   private myPointInSecondImage:Point;
 
 
     /**
      * Create a tie point pair between points representing the same ground coordinate in two different images
      * @param pointInFirstImage The image coordinate of the point in the first image
      * @param pointInSecondImage The image coordinate of the point in the second image
      */
   public constructor( pointInFirstImage:Point,
                        pointInSecondImage:Point)
   {
     this.myPointInFirstImage  = pointInFirstImage;
     this.myPointInSecondImage = pointInSecondImage;
   }
 
     /**
      * Get the image coordinate of the point in the first image
      * @return The point as an image coordinate
      */
   public getPointInFirstImage():Point
   {
     return this.myPointInFirstImage;
   }
 
     /**
      * Get the image coordinate of the point in the second image
      * @return The point as an image coordinate
      */
   public getPointInSecondImage():Point
   {
     return this.myPointInSecondImage;
   }
 
     /**
      * @return text description of this tie point pair
      */
   public toString():string
   {
     return "TiePointPar"+"\n  p1 = "+this.myPointInFirstImage+"\n  p2 = "+this.myPointInSecondImage;
   }
 
 }
/**
 * This class provides static methods to compute polynomial coefficients
 * for image warping.
 *
 * polyCoeff() accepts an array of tie points
 * and computes the coefficients of the warping
 * polynomial.  The coefficients are computed using
 * generalized least squares.
 *
 * polyEval() evaluates the polynomial.
 *
 * The warping polynomial F(x,y) associates to each
 * point (x,y) in the first image a corresponding
 * point F(x,y) in the second image.  The point F(x,y)
 * has the form (f1(x,y),f2(x,y)) where f1(x,y) is the
 * x-component, and f2(x,y) the y-component.  f1(x,y)
 * and f2(x,y) are polynomials in the independent
 * variables x and y.  Their form depends on their
 * degree.  If they are linear (degree 1), then they
 * have the form
 *     f1(x,y) = a1 + a2*x + a3*y
 *     f2(x,y) = b1 + b2*x + b3*y
 * If they are quadratic (degree 2), then they have
 * the form
 *     f1(x,y) = a1 + a2*x + a3*y + a4*x*x + a5*x*y
 *                  + a6*y*y
 *     f2(x,y) = b1 + b2*x + b3*y + b4*x*x + b5*x*y
 *                  + b6*y*y
 * If they are cubic (degree 3), then they have the
 * form
 *     f1(x,y) = a1 + a2*x + a3*y + a4*x*x + a5*x*y
 *                  + a6*y*y + a7*x*x*x + a8*x*x*y
 *                  + a9*x*y*y + 10*y*y*y
 *     f2(x,y) = b1 + b2*x + b3*y + b4*x*x + b5*x*y
 *                  + b6*y*y + b7*x*x*x + b8*x*x*y
 *                  + b9*x*y*y + 10*y*y*y
 * And so on.  The caller specifies the degree.
 * Function PolyCoeff computes the coefficients (a's
 * and b's) and returns these coefficients along with
 * the chi-square error (a measure of goodness-of-fit
 * of the tie points to the polynomial, equal to the
 * sum of the squared differences between each tie
 * point and the value predicted by the polynomial.)
 *
 */
 export class PolyWarp
 {
 
   public static readonly LINEAR_WARP:number = 1;
   public static readonly  QUASILINEAR_WARP:number = -1;
   public static readonly  QUADRATIC_WARP:number = 2;
   public static readonly  CUBIC_WARP:number = 3;
 
   private static readonly  DEBUG:boolean = false;
 
 
   private  myDegree:number;
   private  myTiePoints:TiePointPair[];
   private  myCoeffs:WarpCoefficientSet;
   private  myMaxError:number = 0.0;
   private  myChiSquaredError:number = 0.0;
 
 
   /**
    * Constructs a PolyWarp. The tie points are stored, along with the
    * coefficients, so that a warp may be easily evaluated multiple times in
    * sequence.
    */
   public constructor(degree:number,  tiePoints:TiePointPair[])
   {
     this.myDegree = degree;
     this.myTiePoints = tiePoints;
     this.myCoeffs = PolyWarp.polyCoeff(this.myDegree, this.myTiePoints);
     let errors:number[] = this.myCoeffs.getErrors();
 
     //myMaxError = ArrayUtils.maxValue(errors);
     // +++
     this.myMaxError = 0;
     for(let i=0; i<tiePoints.length; i++)
     {
       this.myMaxError = Math.max(errors[i], this.myMaxError);
     }
     // +++
 
     this.myChiSquaredError = this.myCoeffs.getChisqr();
   }
 
 
 
 
   // NEW
 
   // MDP: Added Jan 2006 for computation of Affine Transform from 4 points
   public  getCoeffs():WarpCoefficientSet
   {
     return this.myCoeffs;
   }
 
 
 
 
 
 
 
   /**
    * Constructs the invers warp of this PolyWarp. This is done by constructing
    * a new set of tie points containing the original tie points in reverse
    * order, and building a new PolyWarp from these tiePoints. The degree is
    * assumed to be the same as the degree of this PolyWarp.
    */
   public  invertWarp():PolyWarp
   {
     let invertedTiePoints:TiePointPair[] = PolyWarp.invertTies(this.myTiePoints);
     let invertedWarp:PolyWarp = new PolyWarp(this.myDegree, invertedTiePoints);
     return invertedWarp;
   }
 
   /**
    * Inverts the given array of tie points, switching the order of ties
    */
   private static  invertTies(ties:TiePointPair[]):TiePointPair[]
   {
     let inverted:TiePointPair[] = [];
     for(let i=0; i<ties.length; i++)
     {
       inverted[i] = new TiePointPair(ties[i].getPointInSecondImage(),
                                      ties[i].getPointInFirstImage());
     }
     return inverted;
   }
 
   /**
    * Evaluates this PolyWarp for the given point, returning the resulting point.
    */
   public  eval(fromPoint:Point):Point
   {
     let x:number = PolyWarp.polyEval(this.myCoeffs.getACoeffs(), this.myDegree, fromPoint.getX(), fromPoint.getY());
     let y:number = PolyWarp.polyEval(this.myCoeffs.getBCoeffs(), this.myDegree, fromPoint.getX(), fromPoint.getY());
     let mappedPoint:Point = new Point(x,y);   // +++ was Point2D.Double
     return mappedPoint;
   }
 
   /**
    * Gets the maximum error of all tiePoints in this warp.
    */
   public getMaxError():number
   {
     return this.myMaxError;
   }
 
   /**
    * Gets the chi-squared error of all tiePoints defining this warp
    */
   public getChiSquaredError():number
   {
     return this.myChiSquaredError;
   }
 
   /**
    * Accepts an array of tie points and computes the polynomial coefficients.
    * The value of num_tie_points must be >= (degree + 1)*(degree + 2)/2 and
    * coeffs->num will be set equal to (degree + 1)*(degree + 2)/2.
    * The return value from this function is 0 if there was no error.
    *
    * 01/22/98: changed PolyCoeff so it accepts degree=1.  This gives
    * a "quasi-linear" polynomial with the terms 1, x, y, xy.  Exactly
    * four tie points are needed for an exact fit.  Ex: four image corners.
    *
    */
   public static  polyCoeff(
                      degree:number,         // input: degree of poly
           tiePoints:TiePointPair[])      // input: tie points
     :WarpCoefficientSet
   {
     var     i:number, j:number, k:number;
     var      mfit:number;              // number of polynomial coefficients
     var terms:number[];
     var   sum:number, d:number=0.0;
     var   xError:number, yError:number, dError:number;
 
     let numTiePoints:number = tiePoints.length;
 
                                 // compute mfit
     if(degree == this.QUASILINEAR_WARP) // quasi-linear fit
     {
       mfit = 4;
     }
     else
     {
       mfit = (degree + 1)*(degree + 2)/2;
     } // endif
 
                                 // geo.ExcpBadDegree = degree 'degree' < -1
     //assert degree >= -1;
     if (degree < -1) {
        let args:number[] = new Array(1);
       args[0] = Math.floor(degree);
       throw new Error("IllegalDegreeExcp");
     }
     // need at least 'mfit' tie points
     //assert numTiePoints >= mfit;
     if (numTiePoints < mfit) {
       let args:number[] = new Array(3);
       args[0] = Math.floor(numTiePoints);
       args[1] = Math.floor(degree);
       args[2] = Math.floor(mfit);
       throw new Error("NotEnoughTiePtsExcp");
     }
 
     let indx:Array<number> = new Array(mfit);
     
     let covar:number[][]=new Array(mfit)
     .fill(false)
     .map(() => 
       new Array(mfit).fill(false)
     );
     
    let coefa:number[] = new Array(mfit);
    let coefb:number[] = new Array(mfit);
    let errors:number[] = new Array(numTiePoints);
    var chisqr:number;
 
     /* first set of coefficients */
     for(j=0; j<mfit; j++) {
       coefa[j] = 0.0;
       for(k=0; k<mfit; k++) {
         covar[j][k] = 0.0;
       } // endfor k
     } // endfor j
 
     for(i=0; i<numTiePoints; i++) {
       let x1:number = tiePoints[i].getPointInFirstImage().getX();
       let y1:number = tiePoints[i].getPointInFirstImage().getY();
       let x2:number = tiePoints[i].getPointInSecondImage().getX();
 
       if(degree == -1)
       {
         terms = this.fillInQuasiLinearTerms(mfit, x1, y1);
       }
       else
       {
         terms = this.fillInTerms(mfit, degree, x1, y1);
       }
 
       for(j=0; j<mfit; j++) {
         coefa[j] += terms[j]*x2;
         for(k=0; k<mfit; k++) {
           covar[j][k] += terms[j]*terms[k];
         } // endfor k
       } // endfor j
     } // endfor i
 
     d = Matrix.decomposeLU(covar, mfit, indx);
     Matrix.backSubstituteLU(covar, mfit, indx, coefa);
 
     /* second set of coefficients */
     for(j=0; j<mfit; j++) {
       coefb[j] = 0.0;
       for(k=0; k<mfit; k++) {
         covar[j][k] = 0.0;
       } // endfor k
     } // endfor j
 
     for(i=0; i<numTiePoints; i++) {
       let x1:number = tiePoints[i].getPointInFirstImage().getX();
       let y1:number = tiePoints[i].getPointInFirstImage().getY();
       let y2:number = tiePoints[i].getPointInSecondImage().getY();
 
       if(degree == -1)
       {
         terms = this.fillInQuasiLinearTerms(mfit, x1, y1);
       }
       else
       {
         terms = this.fillInTerms(mfit, degree, x1, y1);
       } // endif
       for(j=0; j<mfit; j++) {
         coefb[j] += terms[j]*y2;
         for(k=0; k<mfit; k++) {
           covar[j][k] += terms[j]*terms[k];
         } // endfor k
       } // endfor j
     } // endfor i
     d = Matrix.decomposeLU(covar, mfit, indx);
     Matrix.backSubstituteLU(covar, mfit, indx, coefb);
 
     /* chi-squared error term */
     for(chisqr=0.0, i=0; i<numTiePoints; i++) {
       let x1:number = tiePoints[i].getPointInFirstImage().getX();
       let y1:number = tiePoints[i].getPointInFirstImage().getY();
       let x2:number = tiePoints[i].getPointInSecondImage().getX();
       let y2:number = tiePoints[i].getPointInSecondImage().getY();
 
       if(degree == -1)
       {
         terms = this.fillInQuasiLinearTerms(mfit, x1, y1);
       }
       else
       {
         terms = this.fillInTerms(mfit, degree, x1, y1);
       } // endif
 
       for(sum=0.0, j=0; j<mfit; j++)
         sum += coefa[j]*terms[j];
       xError = x2 - sum;
       chisqr += (xError*xError);
       for(sum=0.0, j=0; j<mfit; j++)
         sum += coefb[j]*terms[j];
       yError = y2 - sum;
       chisqr += (yError*yError);
       dError = Math.sqrt(xError*xError + yError*yError);
       errors[i] = dError;
     }
 
     return(new WarpCoefficientSet(degree, mfit, numTiePoints, coefa, coefb, errors, chisqr));
 
   } // polyCoeff()
 
   /* 012298 Pritt:  Added this function for when degree=-1 in PolyCoeffs */
   private static fillInQuasiLinearTerms(mfit:number, x:number, y:number):number[]
   {
     let terms:number[] = new Array(mfit);
 
     terms[0] = 1.0;
     terms[1] = x;
     terms[2] = y;
     terms[3] = x*y;
 
     return terms;
   } // fillInQuasiLinearTerms()
 
   private static fillInTerms(mfit:number, degree:number, x:number, y:number):number[]
   {
     let terms:number[] = new Array(mfit);
     var    deg:number, i:number, n:number;
 
     for(n=0, deg=0; deg<=degree; deg++) {
       for(i=0; i<=deg; i++) {
         terms[n++] = Math.pow(x,deg-i)*Math.pow(y,i);
       }
     }
 
     return terms;
   } // end fillInTerms()
 
   /**
    * Evaluates a polynomial
    */
   public static polyEval( coeff:number[],  degree:number,  x:number,  y:number):number
   {
     var    deg:number, i:number;
     let n:number=0;
     var val:number;
 
     if(this.DEBUG)
       console.log("   degree = "+degree+", coeffs[1] = "+coeff[1]+"\n");
 
     if(degree == this.QUASILINEAR_WARP)
     {
       val = coeff[0] + coeff[1]*x + coeff[2]*y + coeff[3]*x*y;
     }
     else
     {
       for(val=0.0, n=0, deg=0; deg<=degree; deg++) {  // MDP: Jan 2006: NEW - Corrected bug -- should be <=
         for(i=0; i<=deg; i++) {
           val += coeff[n++]*Math.pow(x,deg-i)*Math.pow(y,i);
         }
       }
     }
 
 
     return val;
   } // end polyEval()
 
   /*
   public static ErrorTerms computeErrorTerms(TiePointPair[] tiePoints, PolyWarp warp)
   {
     ErrorTerms result = new ErrorTerms();
     double maxError = 0.0;
     double chiSqrError = 0.0;
     for(int i=0; i<tiePoints.length; i++)
     {
       Point2D image1Point = tiePoints[i].getPointInFirstImage();
       Point2D image2PointRef = tiePoints[i].getPointInSecondImage();
       Point2D image2PointComp = warp.eval(image1Point);
       double error = image2PointRef.distance(image2PointComp);
       double errorSq = image2PointRef.distanceSq(image2PointComp);
       // maximum error term
       maxError = Math.max(error, maxError);
       // sum of squares of error terms
       chiSqrError += errorSq;
       System.err.println("PolyWarp: Image 1 point "+image1Point+" maps to "+
         image2PointComp);
       System.err.println("  actual point is "+image2PointRef+" error distance is "+error+" pixels");
     }
     result.maxError = maxError;
     result.chiSquaredError = chiSqrError;
     return result;
   }
 
   private static class ErrorTerms
   {
     double maxError;
     double chiSquaredError;
   }
   */
 
 
   // ----------------------------------------------------------------------
                                 // test driver
 /*
   public static void main( String[] args )
   {
     final int NUM_TIE_POINTS = 4;
 
     double latitude = 21.0;     // was 33
     double longitude = 51.0;
 
     int xsize = 200;
     int ysize = 300;
 
     double transx = 0.0;
     double transy = 0.0;
 
     ApplicationConfigurationBuilder.configure();
 
     TiePointPair[] tpp = new TiePointPair[NUM_TIE_POINTS];
     tpp[0] = new TiePointPair(
       new Point2D.Double( 20.0,  50.0),      // 50 was 170.
       new Point2D.Double(  0.0,   0.0)
       );
     tpp[1] = new TiePointPair(
       new Point2D.Double( 30.0,  50.0),
       new Point2D.Double((double)xsize - 1,   0.0)
       );
     tpp[2] = new TiePointPair(
       new Point2D.Double( 30.0,  60.0),
       new Point2D.Double((double)xsize - 1, (double)ysize - 1)
       );
     tpp[3] = new TiePointPair(
       new Point2D.Double( 20.0,  60.0),
       new Point2D.Double(  0.0, (double)ysize - 1)
       );
 
 
     WarpCoefficientSet coeffs = PolyWarp.polyCoeff(-1, tpp);
 
     transx = PolyWarp.polyEval(
       coeffs.getACoeffs(),
       coeffs.getDegree(),
       latitude,
       longitude);
     transy = PolyWarp.polyEval(
       coeffs.getBCoeffs(),
       coeffs.getDegree(),
       latitude,
       longitude);
 
     System.out.println(" PolyWarp Test Driver: "
       + " latitude = " + latitude
       + " longitude = " + longitude
       + " xsize = " + xsize
       + " ysize = " + ysize
       + " transx = " + transx
       + " transy = " + transy
       );
 
     try
     {
 //      System.in.read();
     }
     catch(Exception e)
     {
       System.err.println(e);
     } // end try/catch
 
   } // end main()
 */
 
 } // end PolyWarp