import * as UPNG from 'upng-js';


export class BufferedImage {

    public imageData: Uint8Array;
    public width: number;
    public height: number;
    public depth: number;
    public ctype: UPNG.ctype;
    
    constructor(png: any) {
        var decoded = UPNG.decode(png)
        this.imageData = decoded.data;
        this.width = decoded.width;
        this.height = decoded.height;
        this.depth = decoded.depth;
        this.ctype = decoded.ctype;
    }
}