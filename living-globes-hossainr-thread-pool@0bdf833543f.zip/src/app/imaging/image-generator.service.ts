import { Injectable } from '@angular/core';
import { FeatureCollection } from '@turf/turf';
import { TileCacheService } from '../tileserver-client/tile-cache.service';
import { TileRef } from '../tileserver-client/tile-ref';
import { TileserverClient } from '../tileserver-client/tileserver-client.service';
import { TileServerImage } from '../tileserver-client/tileserver-image';

@Injectable({
  providedIn: 'root'
})
export class ImageGeneratorService {

  private worker;
  private resolvers: {[id: number]: any } = {}
  private rejecters: {[id: number]: any } = {}
  private count = 0;

  constructor(private tileServerClient: TileserverClient, private tileCache: TileCacheService) { 
    this.worker = new Worker(new URL('./generator.worker', import.meta.url));
  }

  getImage(imagery: FeatureCollection): Promise<ImageBitmap> {
    const id = this.count++;

    const htmlCanvas = document.createElement('canvas');
    htmlCanvas.width = 256;
    htmlCanvas.height = 256;

    // @ts-ignore # this was removed from libdom because its "experimental" but is fully supported in chrome
    const offscreen = htmlCanvas.transferControlToOffscreen()

    // var img_url = 'assets/tiles/XVIEWCHALLENGE-00005/20180116034512/0/0/0/0.png'
    var tileserverImage = new TileServerImage("XVIEWCHALLENGE-00005", "20180116034512", this.tileServerClient, this.tileCache);
    tileserverImage.getTileserverTile(new TileRef(tileserverImage.collectionId, tileserverImage.timestamp, 0,0,0,0)).subscribe(
      (image) => {
      this.worker.postMessage({
        "width": 256, 
        "height": 256,
        "id": id,
        "image": image,
        "canvas": offscreen
        }, 
        [offscreen, image.imageData.buffer])
      }
    )
    
    var promise = new Promise<ImageBitmap>((resolve, reject) => {
      this.resolvers[id] = resolve;      
      this.rejecters[id] = reject;
    })
    
    this.worker.onmessage = ({ data }) => {
      var task_id = data['id']
      if (data['success']) {
        this.resolvers[task_id](data['bitmap']);
      } else {
        this.rejecters[task_id](data['failure_message'])
      }
      delete this.resolvers[task_id]
      delete this.rejecters[task_id]
    };

    return promise;
  }
}
