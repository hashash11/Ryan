export class ImageWorld {

    constructor() {

    }

    
}