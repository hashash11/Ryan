/// <reference lib="webworker" />
import {Matrix4} from '@math.gl/core'
import { BufferedImage } from './buffered-image';

function loadShader(gl: WebGL2RenderingContext, type: number, source: string): WebGLShader | null {
  var shader = gl.createShader(type);
  if(shader!=null){
    try {
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      return shader;
    } catch(ex) {
      console.error("Error compiling shader\n" + ex);
      return null;
    }
  } else {
    console.error("Error in gl.createShader())")
    return null;
  }
}

function createShaderProgram(gl: WebGL2RenderingContext, shaderGLSL: {vert: string, frag: string}) {
  
  var vertexShader = loadShader(gl, gl.VERTEX_SHADER, shaderGLSL.vert);
  var fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, shaderGLSL.frag);
  
  if(!vertexShader || !fragmentShader){
    return null;
  }

  var program = gl.createProgram();

  if(!program) {
    console.error("error in gl.createProgram()")
    return null;
  }

  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  return program;
}

function initShaders(gl: WebGL2RenderingContext, shaderGLSL: {vert: string, frag: string}): WebGLProgram | null {
  var program = createShaderProgram(gl, shaderGLSL);
  if(program){
    gl.useProgram(program);
    return program;
  } else {
    return null;
  }

}

var shaders = {
  frag:
    `
    precision mediump float;
 
    varying vec2 v_texcoord;
     
    uniform sampler2D u_texture;
     
    void main() {
       gl_FragColor = texture2D(u_texture, v_texcoord);
    }
    `,
  vert:
    `
    attribute vec4 a_position;
    attribute vec2 a_texcoord;
     
    uniform mat4 u_matrix;
     
    varying vec2 v_texcoord;
     
    void main() {
       gl_Position = u_matrix * a_position;
       v_texcoord = a_texcoord;
    }
    `
}

addEventListener('message', ({ data }) => {

  var width = data['width'];
  var height = data['height'];
  var image: BufferedImage = data['image'];
  var offscreen = data['canvas']

  const gl: WebGL2RenderingContext = offscreen.getContext("webgl2");
  try {    
    if (!gl) {
      throw "failed creating a webgl context (generator.worker.ts)"
    }

    var program = initShaders(gl, shaders);
    if(!program) {
      throw "Failure initializing shader program"
    }
    // look up where the vertex data needs to go.
    var positionLocation = gl.getAttribLocation(program, "a_position");
    var texcoordLocation = gl.getAttribLocation(program, "a_texcoord");

    // lookup uniforms
    var matrixLocation = gl.getUniformLocation(program, "u_matrix");
    var textureLocation = gl.getUniformLocation(program, "u_texture");

    // Create a buffer.
    var positionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);

    // Put a unit quad in the buffer
    var positions = [
      0, 0,
      0, 1,
      1, 0,
      1, 0,
      0, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);

    // Create a buffer for texture coords
    var texcoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, texcoordBuffer);

    // Put texcoords in the buffer
    var texcoords = [
      0, 0,
      0, 1,
      1, 0,
      1, 0,
      0, 1,
      1, 1,
    ];
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(texcoords), gl.STATIC_DRAW);
    
    var tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, image.width, image.height, 0, gl.RED, gl.UNSIGNED_BYTE, image.imageData, 0);

    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);

    gl.clear(gl.COLOR_BUFFER_BIT);
  
    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.enableVertexAttribArray(positionLocation);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, texcoordBuffer);
    gl.enableVertexAttribArray(texcoordLocation);
    gl.vertexAttribPointer(texcoordLocation, 2, gl.FLOAT, false, 0, 0);
    
    const transform = new Matrix4()
      .ortho({left: 0, right: width, bottom: height, top: 0, near: -1, far: 1})
      .scale([image.width, image.height, 1])
 
    // Set the matrix.
    gl.uniformMatrix4fv(matrixLocation, false, transform);
    // Tell the shader to get the texture from texture unit 0
    gl.uniform1i(textureLocation, 0);
 
    // draw the quad (2 triangles, 6 vertices)
    gl.drawArrays(gl.TRIANGLES, 0, 6);    

    var bitmap = offscreen.transferToImageBitmap();

    var response = {
      "bitmap": bitmap,
      "id": data['id'],
      "success": true,
      "failure_message": ""
    }

    postMessage(response, [response.bitmap]);
    
  } catch(error: any) {
    console.error(error)
    var bitmap: any = new ArrayBuffer(0)

    var response = {
      "bitmap": bitmap,
      "id": data['id'],
      "success": false,
      "failure_message": "" + error
    }
    postMessage(response, [response.bitmap]);
  }
});
