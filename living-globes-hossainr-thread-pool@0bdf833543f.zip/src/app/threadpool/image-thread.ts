import { spawn, Pool, Worker } from "threads"

const pool = Pool(() => spawn(new Worker("./imaging/generator")), 8 /* optional size */)

pool.queue(async multiplier => {
  const multiplied = await multiplier(2, 3)
  console.log(`2 * 3 = ${multiplied}`)
})

 pool.completed()
 pool.terminate()