declare module 'upng-js' {
    /**
    https://github.com/photopea/UPNG.js
    UPNG.decode(buffer)
        buffer: ArrayBuffer containing the PNG file
    returns an image object with following properties:
        width: the width of the image
        height: the height of the image
        depth: number of bits per channel
        ctype: color type of the file (Truecolor, Grayscale, Palette ...)
        frames: additional info about frames (frame delays etc.)
        tabs: additional chunks of the PNG file
        data: pixel data of the image
    */
   
    export enum ctype {
        Grayscale = 0,  // GL.LUMINANCE (our images are always this from the tileserver because we serve 1 band at a time)
        RGB = 2,        // GL.RGB
        Palette = 3,
        GrayAlpha = 4,  // GL.LUMINANCE_ALPHA
        RGBA = 6        //GL.RGBA
    }

    export interface UPNGImage {
        width: number, 
        height: number,
        depth: number,
        ctype: ctype,
        frames: [],
        tabs: {},
        data: Uint8Array
    }
    
    export function decode(buffer: ArrayBuffer): UPNGImage;

    export function toRGBA8(image: UPNGImage): ArrayBuffer[];
}