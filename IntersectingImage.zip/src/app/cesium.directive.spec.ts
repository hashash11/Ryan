import { CesiumDirective } from './cesium.directive';

describe('CesiumDirective', () => {
  it('should create an instance', () => {
    const directive = new CesiumDirective();
    expect(directive).toBeTruthy();
  });
});
