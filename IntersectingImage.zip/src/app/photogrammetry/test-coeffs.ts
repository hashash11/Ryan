// import { AppComponent } from "../app.component";
// import { Directive, ElementRef, OnInit } from '@angular/core';
// import { FourCornerBasedCameraModel,Coordinate, WorldImage } from './app.cameramodel';
// import { WarpCoefficientSet,Point } from './app.warp';

// var PerspT = require("perspective-transform");




// @Directive
// ({
//   selector:'testCoeffs'
// })
// export class TestCoeffsComponent{

    
//     static testGetCoeffs(){
//     //
    
//         //dummy data is ordered as follows: (topLeft Coords, topRight Coords, botRight coords, botLeft Coords, z value, origin image coords, width,height)
//         let dummyData=[40.2656, 99.4128, //topLeft
//         40.2705,99.5322, //topRight
//         40.1949,99.5322, //botRight
//         40.1940,99.4128, //botLeft
//         1099, //z value: elevation
//         0,0, //origin 
//         9216,7168]; //width, height
//         let myImageData = new WorldImage(new Coordinate(dummyData[1],dummyData[0],dummyData[8]),
//         new Coordinate(dummyData[3],dummyData[2],dummyData[8]),
//         new Coordinate(dummyData[5],dummyData[4],dummyData[8]),
//         new Coordinate(dummyData[7],dummyData[6],dummyData[8]), 
//         dummyData[8],
//         new Point(dummyData[9],dummyData[10]),
//         dummyData[11],
//         dummyData[12] );

//         let coeffs1 = this.getCameraWarpCoeffsLatLongToSource(myImageData);
//         let coeffs2 = this.getCameraWarpCoeffsSourceToLatLong(myImageData);
//         let myPoint = this.getCoordFromSource(myImageData);
//         let myCoord = this.getSourceFromCoord(myImageData);
        
//         console.log(coeffs1);
//         console.log(coeffs2);
//         console.log(myPoint);
//         console.log(myCoord);
//         let  myPerspT = this.getProjCoord(myImageData);
//         console.log(myPerspT.transform(0,0));

        

//     }
//     static  getCameraWarpCoeffsLatLongToSource(image:WorldImage ):WarpCoefficientSet{
//         let imgCoords:Coordinate[] = new Array<Coordinate>(4)
//         imgCoords[0]= image.getTopLeft(); // upper left in "Long, Lat"
//         imgCoords[1]= image.getTopRight(); // upper right in "Long, Lat"
//         imgCoords[2]= image.getBotRight(); // lower right in "Long, Lat"
//         imgCoords[3]= image.getBotLeft(); // lower left in "Long, Lat"

//         const camera = new FourCornerBasedCameraModel(image.getWidth(),image.getHeight(), imgCoords, image.getOrigin()) // origin
//         return camera.getMyCoeffsFromLatLongToSource();
//     }

//    static  getCameraWarpCoeffsSourceToLatLong(image:WorldImage):WarpCoefficientSet{
//         let imgCoords:Coordinate[] = new Array<Coordinate>(4)
//         imgCoords[0]= image.getTopLeft(); // upper left in "Long, Lat"
//         imgCoords[1]= image.getTopRight(); // upper right in "Long, Lat"
//         imgCoords[2]= image.getBotRight(); // lower right in "Long, Lat"
//         imgCoords[3]= image.getBotLeft(); // lower left in "Long, Lat"
    
//        const camera = new FourCornerBasedCameraModel(image.getWidth(),image.getHeight(), imgCoords, image.getOrigin()) // origin 
//          return camera.getMyCoeffsFromSourceToLatLong();
//       }

//       //test method gets top left corner, adds to it (positive long), and spits out it's new image coord
//       static  getCoordFromSource(image:WorldImage):Point{
//         let imgCoords:Coordinate[] = new Array<Coordinate>(4)
//         imgCoords[0]= image.getTopLeft(); // upper left in "Long, Lat"
//         imgCoords[1]= image.getTopRight(); // upper right in "Long, Lat"
//         imgCoords[2]= image.getBotRight(); // lower right in "Long, Lat"
//         imgCoords[3]= image.getBotLeft(); // lower left in "Long, Lat"
    
//        const camera = new FourCornerBasedCameraModel(image.getWidth(),image.getHeight(), imgCoords, image.getOrigin()) // origin 
//          return camera.worldToImage(new Coordinate(image.getTopLeft().getX(),image.getTopLeft().getY(),image.getTopLeft().getZ()));
//       }

//       //test method gets asks for image coord and should spit out proper coord
//       static  getSourceFromCoord(image:WorldImage):Coordinate{
//         let imgCoords:Coordinate[] = new Array<Coordinate>(4)
//         imgCoords[0]= image.getTopLeft(); // upper left in "Long, Lat"
//         imgCoords[1]= image.getTopRight(); // upper right in "Long, Lat"
//         imgCoords[2]= image.getBotRight(); // lower right in "Long, Lat"
//         imgCoords[3]= image.getBotLeft(); // lower left in "Long, Lat"
    
//        const camera = new FourCornerBasedCameraModel(image.getWidth(),image.getHeight(), imgCoords, image.getOrigin()) // origin 
//          return camera.imageToWorld(new Point(0,0));
//       }

//       static  getProjCoord(image:WorldImage ):typeof PerspT{
//         let imgCoords:Coordinate[] = new Array<Coordinate>(4)
//         imgCoords[0]= image.getTopLeft(); // upper left in "Long, Lat"
//         imgCoords[1]= image.getTopRight(); // upper right in "Long, Lat"
//         imgCoords[2]= image.getBotRight(); // lower right in "Long, Lat"
//         imgCoords[3]= image.getBotLeft(); // lower left in "Long, Lat"

//         const camera = new FourCornerBasedCameraModel(image.getWidth(),image.getHeight(), imgCoords, image.getOrigin()) // origin 
//         return camera.getImageToProjectedMatrix(image);
//     }
        
// }