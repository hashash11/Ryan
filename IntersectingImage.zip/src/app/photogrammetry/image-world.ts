import { polygon, Polygon, Position } from "@turf/turf";
import * as math from 'mathjs';
import { CameraModel, Coordinate } from './camera-model';
import { Point2D } from './warp';
import { Vector2, Vector3, Matrix4, Matrix3, Vector4 } from '@math.gl/core';
import { Proj4Projection } from '@math.gl/proj4';
import { TileRef } from "../tileserver-client/tile-ref";
import { Math as CesiumMath, Rectangle as CesiumRectangle } from "cesium";
import { TileserverImage } from "../tileserver-client/tileserver-image";
import { Rectangle } from "../shapes/rectangle";
import { PerspectiveTransform } from "./perspective-transform";


//ImageWorld constants
const IDENTITY = new Matrix4();
const CLIP_ORIGIN = new Vector3(0.0, 0.0, 0.0);
const X_AXIS = new Vector3(1.0, 0.0, 0.0);
const Y_AXIS = new Vector3(0.0, 1.0, 0.0);
const EPSILON = 1E-3;
//	const double EPSILON = 1E-5;
const EPSILON2D = new Vector2(EPSILON, EPSILON);

//Bounds for webmercator, should be locked to some external lib but here it is.
const WEB_MERCATOR_PROJECTION_XSPAN: number = 20026376.39 - -20026376.39;
const WEB_MERCATOR_PROJECTION_YSPAN: number = 20048966.1 - -20048966.1;


//Map Scale constants
const EARTH_RADIUS_METERS = 6378137.0;
const EARTH_CIRCUMFERENCE_METERS = 2.0 * math.pi * EARTH_RADIUS_METERS;
const TOP_MAP_TILE_PIXELS = 256.0;
const EARTH_CIRCUMFERENCE_METERS_PER_PIXEL = EARTH_CIRCUMFERENCE_METERS / TOP_MAP_TILE_PIXELS;
const MAP_DIM = new Vector2(WEB_MERCATOR_PROJECTION_XSPAN, WEB_MERCATOR_PROJECTION_YSPAN);
const MAP_Z0_SCALE = TOP_MAP_TILE_PIXELS / math.max(MAP_DIM.x, MAP_DIM.y);
const MAP_Z0_DIM = MAP_DIM.multiplyByScalar(MAP_Z0_SCALE);

const MAX_ZOOM = 25.0;
const MIN_ZOOM = 0.0;
const DEFAULT_ZOOM = MIN_ZOOM;

export class MapWebGLView {

    //Angle of rotation of north, let's say it's in radians
    private rotateOffNorth = 0;
    constructor() {

    }

    public getTSRMatrix(zoom: number): Matrix4 {
        const scaleNum = Number(math.pow(2.0, zoom))
        const scale: Vector2 = new Vector2(scaleNum, scaleNum);
        const rotate: number = this.rotateOffNorth * -1.0
        const translate: Vector3 = (this.getWorldCenter().multiply(new Vector3(scaleNum, scaleNum, 1))).multiplyByScalar(-1);

        //		System.out.println(String.format("scale = %s rotate = %f translate = %s", scale.toString(), rotate, translate.toString()));

        const tsrMatrix: Matrix4 = new Matrix4()
            .translate([translate[0], translate[1], translate[2]])
            .scale([scale.x, scale.y, 1.0])
            .rotateZ(rotate);

        return tsrMatrix;
    }

    //The java code equivalent of this is..... well...
    public getWorldCenter(): Vector3 {
        return new Vector3(0, 0, 0);
    }
}

export class ImageWorld {

    private screenSize: Vector2;
    private view: MapWebGLView;
    private zoom: number;
    private webMercToWGS84: Proj4Projection;
    // unlike ELT our geodetic viewport is known because it is in the cesium mercator tile request
    private geodeticViewport: Polygon;


    constructor(screenWidth: number, screenHeight: number, geodeticViewport: Polygon) {
        this.screenSize = new Vector2(screenWidth, screenHeight);
        this.view = new MapWebGLView()
        this.zoom = 0;
        this.webMercToWGS84 = new Proj4Projection({ from: "EPSG:3857", to: "WGS84" });
        
        this.geodeticViewport = geodeticViewport;
        
    }

    public getRset(imageCameraModel: CameraModel, latLon: Coordinate, zoom: number, tileDim: number): number {
        let mapGSD: number = this.getGSD(latLon, zoom,tileDim);
        let r0GSD: number = imageCameraModel.getGSD(new Point2D(latLon.getX(), latLon.getY()));
        return math.log2(mapGSD / r0GSD);
    }

    public getGSD(latLon: Coordinate, zoom: number, tileDim: number): number {
        const result = EARTH_CIRCUMFERENCE_METERS/tileDim * math.cos(CesiumMath.toRadians(latLon.getY())) / Number(math.pow(2.0, zoom));;
        return result;

    }
    public getZoomForCoord(latLon: Coordinate, pixels: number, meters: number) {
        const result = math.log2(math.cos(CesiumMath.toRadians(latLon.getY())) * pixels * EARTH_CIRCUMFERENCE_METERS_PER_PIXEL / meters);
        return result;
    }

    //let's see if we need "MapScale" at all.
    /*public getMapScale(TileserverImage image, Coordinate latLon, double rset) {
        return MapScale.mapScaleForGSD(latLon, image.getGSD(latLon, rset));
    
    }*/

    public getZoom() {
        return this.zoom
    }

    public setZoom(zoom: number) {
        this.zoom = zoom;
    }

    public getGeodeticViewport(): Polygon {
        return this.geodeticViewport;
    }

    private projectedToGeodetic(coordinate: Position) {
        //this coord is coming in as an array [x,y]
        //we're going from WebMercator -> WGS84
        return this.webMercToWGS84.project([coordinate[0], coordinate[1]]);
    }

    private geodeticToProjected(coordinate: Position) {
        return this.webMercToWGS84.unproject([coordinate[0], coordinate[1]]);
    }

    public getCurrentViewport(): Rectangle {
        return new Rectangle(0,0,this.screenSize.x, this.screenSize.y);
    }

    public getGeodeticCenter(): Coordinate {
        var c = this.geodeticViewport.coordinates[0]
        var center = CesiumRectangle.center(
                    new CesiumRectangle(c[0][0], c[0][1], c[2][0], c[2][1]))
        return new Coordinate(center.longitude, center.latitude, 0.0)
    }

    public getProjectedTile(tileRef: TileRef): Polygon {
        var imageSpaceBounds: Polygon = tileRef.getImageSpaceBounds();
        var projectedBounds = imageSpaceBounds.coordinates[0].map(c => {
            var projected: Point2D = this.imageToProjected(tileRef.image, new Point2D(c[0], c[1]))
            return [projected.x, projected.y]
        });
        return polygon([projectedBounds]).geometry
    }    
    
    public getGeodeticTile(tileRef: TileRef): Polygon {
        var imageSpaceBounds: Polygon = tileRef.getImageSpaceBounds();
        var projectedBounds = imageSpaceBounds.coordinates[0].map(c => {
            var projected: Coordinate = this.imageToGeodetic(tileRef.image, new Point2D(c[0], c[1]))
            return [projected.x, projected.y]
        });
        return polygon([projectedBounds]).geometry
    }

    public imageToGeodetic(image: TileserverImage, imageCoord: Point2D): Coordinate {
        return image.cameraModel.imageToWorld(imageCoord);
    }

    public imageToProjected(image: TileserverImage, imageCoord: Point2D): Point2D {
        var geodeticPoint = this.imageToGeodetic(image, imageCoord)
        var projected = this.geodeticToProjected([geodeticPoint.x, geodeticPoint.y]);
        return new Point2D(projected[0], projected[1]);
    }
    
    public getWebGLMVPMatrix(): Matrix4 {
        
        // Build a matrix that transforms geodetic coordinates into coordinates in clip space
        // var coords: Position[] = this.geodeticViewport.coordinates[0].map(c => this.geodeticToProjected(c))
        var coords = this.geodeticViewport.coordinates[0];
        
        var order: number[] = [0,1,2,3]
        var perspTr: Matrix3 = PerspectiveTransform.getQuadToQuad([
            coords[order[0]][0], coords[order[0]][1], //LL
            coords[order[1]][0], coords[order[1]][1], //UL
            coords[order[2]][0], coords[order[2]][1], //UR
            coords[order[3]][0], coords[order[3]][1]  //LR
        ],
        [
            -1.0,  1.0,
             1.0, 1.0,
             1.0,  -1.0,
             -1.0, -1.0
        ])

        return new Matrix4().setRowMajor(perspTr[0], perspTr[3], 0.0, perspTr[6],
                                         perspTr[1],  perspTr[4], 0.0, perspTr[7],
                                         0.0,         0.0,        1.0, 0.0,
                                         perspTr[2],  perspTr[5], 0.0, perspTr[8])
    }

    public getWebGLImageMVPMatrix(image: TileserverImage): Matrix4 {
        // Combine our two projection matrices. ABx = y
        // B is applied to the pixel coordinate first, it turns image coordinates into geodetic coordinates
        // A is applied next, it turns geodetic coordinates into clip space (webgl) coordinates
        var imageToProjected: Matrix4 = this.getImageToProjected(image);
        var projectedToClip: Matrix4 = this.getWebGLMVPMatrix();

        // var testUL = new Vector4(0, 0, -3, 1)
        // var testUR = new Vector4(3094, 0, -3, 1)
        // var testLR = new Vector4(3094, 2606, -3, 1)
        // var testLL = new Vector4(0, 2606, -3, 1)
        // console.log("Testing imageToProjected transform for image " + image.collectionId + "/" + image.timestamp)
        // console.log("Image BBOX: " + image.getBoundingBox())
        // console.log("UL: " + testUL.transform(imageToProjected))
        // console.log("UR: " + testUR.transform(imageToProjected))
        // console.log("LR: " + testLR.transform(imageToProjected))
        // console.log("LL: " + testLL.transform(imageToProjected))

        // testLL = new Vector4(-70.82, -33.41, -2.86e-7, 1)
        // testUL = new Vector4(-70.81, -33.41, -2.86e-7, 1)
        // testLR = new Vector4(-70.81, -33.42, -2.86e-7, 1)
        // testUR = new Vector4(-70.82, -33.42, -2.86e-7, 1)
        // console.log("Testing projectedToClip transform for image " + image.collectionId + "/" + image.timestamp)
        // console.log("Image BBOX: " + image.getBoundingBox())
        // console.log("UL: " + testUL.transform(projectedToClip))
        // console.log("UR: " + testUR.transform(projectedToClip))
        // console.log("LR: " + testLR.transform(projectedToClip))
        // console.log("LL: " + testLL.transform(projectedToClip))

        // note that multiplyRight alters projectedToClip in place as well
        // it could be computed just once when this class is constructed but we must be careful not to mutate it with
        // each call in that case
        return projectedToClip.multiplyRight(imageToProjected);
    }

    public getImageToProjected(image: TileserverImage): Matrix4 {

        // Build a matrix that transforms coordinates from image space (pixel coordinates) into geodetic coordinates
        var imageBounds: Point2D[] = image.getR0ImageBounds();
        // var projectedBounds: Point2D[] = imageBounds.map((p) => {return this.imageToProjected(image, p)});
        var projectedBounds: Point2D[] = imageBounds.map((p) => {
            var coord = this.imageToGeodetic(image, p)
            return new Point2D(coord.x, coord.y)
            });
        
        var order: number[] = [0,1,2,3]
        var perspTr: Matrix3 = PerspectiveTransform.getQuadToQuad([
            imageBounds[order[0]].x, imageBounds[order[0]].y,
            imageBounds[order[1]].x, imageBounds[order[1]].y,
            imageBounds[order[2]].x, imageBounds[order[2]].y,
            imageBounds[order[3]].x, imageBounds[order[3]].y
        ], 
        [
            projectedBounds[order[0]].x, projectedBounds[order[0]].y,
            projectedBounds[order[1]].x, projectedBounds[order[1]].y,
            projectedBounds[order[2]].x, projectedBounds[order[2]].y,
            projectedBounds[order[3]].x, projectedBounds[order[3]].y
        ])

        return new Matrix4().setRowMajor(perspTr[0], perspTr[3], 0.0, perspTr[6],
                                         perspTr[1],  perspTr[4], 0.0, perspTr[7],
                                         0.0,         0.0,        1.0, 0.0,
                                         perspTr[2],  perspTr[5], 0.0, perspTr[8])

    }
    


    public getOpenGLProjection(): Matrix4 {
        let scaledProjection: Vector2 = this.getScaledProjection();
        //create an orthographic symmetric projection matrix given a height and width, in this case, our scaled screen size.
        let result = new Matrix4().ortho({
            left: -scaledProjection.x / 2,
            right: scaledProjection.x / 2,
            top: -scaledProjection / 2,
            bottom: scaledProjection.y / 2,
            near: 1,
            far: -1
        })
        return result;
    }


    public getScaledProjection() {
        let viewport: Vector2 = new Vector2([this.screenSize.x, this.screenSize.y])
        let scaledProjection: Vector2 = viewport.multiplyByScalar(Number(math.pow(2, this.getScaleDiff())));
        return scaledProjection;
    }


    public getScaleDiff() {
        //kinda lost here but as far as I can tell it just tries to get the difference between our fullProjection scale and the top scale (0?) so.... zoom?
        return this.zoom;

    }

    //We'll se if these are needed
    public getProjectedImage() {
    }

    public getPercentVisible() {
    }







}