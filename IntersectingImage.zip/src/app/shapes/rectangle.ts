export class Rectangle {

    x: number;
    y: number;
    width: number;
    height: number;
    
    constructor(x: number, y: number, width: number, height: number) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    getMinX(): number {
        return Math.min(this.x, this.x+this.width);
    }

    getMinY(): number {
        return Math.min(this.y, this.y+this.height);
    }

    getMaxX(): number {
        return Math.max(this.x, this.x+this.width);
    }

    getMaxY(): number {
        return Math.max(this.y, this.y+this.height);
    }

    intersects(r: Rectangle): boolean {
        if (r.width <= 0 || r.height <= 0 || this.width <= 0 || this.height <= 0) {
            return false;
        }
        var tw = this.width;
        var th = this.height;
        var rw = r.width;
        var rh = r.height;
        var tx = this.x;
        var ty = this.y;
        var rx = r.x;
        var ry = r.y;
        rw += rx;
        rh += ry;
        tw += tx;
        th += ty;
        return ((rw < rx || rw > tx) &&
                (rh < ry || rh > ty) &&
                (tw < tx || tw > rx) &&
                (th < ty || th > ry));
    }

    intersection(r: Rectangle): Rectangle {
        var tx1 = this.x;
        var ty1 = this.y;
        var rx1 = r.x;
        var ry1 = r.y;
        var tx2 = tx1; tx2 += this.width;
        var ty2 = ty1; ty2 += this.height;
        var rx2 = rx1; rx2 += r.width;
        var ry2 = ry1; ry2 += r.height;
        if (tx1 < rx1) tx1 = rx1;
        if (ty1 < ry1) ty1 = ry1;
        if (tx2 > rx2) tx2 = rx2;
        if (ty2 > ry2) ty2 = ry2;
        tx2 -= tx1;
        ty2 -= ty1;
        return new Rectangle(tx1, ty1, tx2, ty2);
    }
}