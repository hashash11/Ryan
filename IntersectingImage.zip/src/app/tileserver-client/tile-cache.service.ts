import { Injectable } from '@angular/core';
import { NgxIndexedDBService } from 'ngx-indexed-db';
import { catchError, map, Observable, throwError } from 'rxjs';
import { BufferedImage } from '../imaging/buffered-image';
import { TilePyramidDescriptor } from './tile-pyramid-descriptor';
import { TileRef } from './tile-ref';
import { TileserverClient } from './tileserver-client.service';
import { retryBackoff } from 'backoff-rxjs';


export interface CachedTile {
    tileKey: string;
    imageData: BufferedImage;
}

export interface CachedMetadata {
    imageId: string;
    metadata: TilePyramidDescriptor;
}


@Injectable({
    providedIn: 'root'
  })
export class TileCacheService {

    constructor(private tileServerClient: TileserverClient, private dbService: NgxIndexedDBService) {

    }

    getTile(tileRef: TileRef): Observable<BufferedImage> {
        
        return (<Observable<CachedTile>> this.dbService.getByIndex("imagery", "tileKey", tileRef.getCacheKey())).pipe(
            map((result) => {
                     if(!result) {
                         throw new Error('Not found in cache');
                     } else {
                        console.log("Got a tile from the cache!");
                         return result;
                     }
                }
            ),
            catchError((err, caught) => {
                // not found in cache                
                return this.tileServerClient.getTile(tileRef).pipe(                    
                    map(response => {
                        return new BufferedImage(response);
                    }),
                    // Decoding corrupted images will throw an error, so retry the request for an uncorrupted image.
                    // TODO: Detect more subtle signs of a corrupted image.
                    retryBackoff(({
                        initialInterval: 50,
                        backoffDelay: (iteration, initialInterval) => Math.pow(2, iteration) * initialInterval
                    })),
                    map(image => {
                        var cacheTile: CachedTile = {
                            tileKey: tileRef.getCacheKey(),
                            imageData: image
                        };
                        this.dbService.add("imagery", cacheTile).pipe(
                            catchError((err, caught) => {
                                // currently I suspect this errors with uniqueness constraint when zooming because we might make two
                                // requests for a tile before one is fulfilled, for example when an image tile straddles two map tiles
                                // so I'm just ignoring it
                                return caught;
                            }))
                            .subscribe((result) => {
                                console.log('added a tile to the cache');
                          });
                        return cacheTile;
                    })
                )
            }),
            map((cachedTile) => cachedTile.imageData)
        );
    }

    getMetadata(collectionId: string, timestamp: string): Observable<TilePyramidDescriptor> {

        var imageId = collectionId + ":" + timestamp;
        
        return (<Observable<CachedMetadata>> this.dbService.getByIndex("metadata", "imageId", imageId)).pipe(
            map((result) => {
                     if(!result) {
                         throw new Error('Not found in cache');
                     } else {
                         return result;
                     }
                }
            ),
            catchError((err, caught) => {
                // not found in cache                
                return this.tileServerClient.getMetadata(collectionId, timestamp).pipe(
                    map(meta => {
                        var cacheMetadata: CachedMetadata = {
                            imageId: imageId,
                            metadata: meta
                        };
                        this.dbService.add("metadata", cacheMetadata).subscribe((key) => {
                            console.log('key: ', key);
                          });
                        return cacheMetadata;
                    })
                );
            }),
            map(cacheMetadata => cacheMetadata.metadata)
        );
    }
}