import { Polygon } from "@turf/turf";

export interface ImageryEssentialMetadata {
    NROWS: number;
    NCOLS: number;
    NBANDS: number;
}

export interface ImageryMetadata extends ImageryEssentialMetadata {
    [key : string]: any;
}

export interface TilePyramidDescriptor {
    edhIdentifier: string;
    name: string;
    metadata: ImageryMetadata,
    tileWidth: number,
    tileHeight: number,
    width: number,
    height: number,
    minrlevel: number,
    maxRLevel: number,
    boundingBox: number[],
    bounds: Polygon
}