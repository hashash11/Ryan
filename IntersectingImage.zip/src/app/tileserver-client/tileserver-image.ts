import { of, map, Observable, forkJoin } from "rxjs";
import { CameraModel, Coordinate, FourCornerBasedCameraModel } from "../photogrammetry/camera-model";
import { TilePyramidDescriptor } from "./tile-pyramid-descriptor";

import { TileRef } from "./tile-ref";
import { TileCacheService } from "./tile-cache.service";
import { TileserverClient } from "./tileserver-client.service";
import { BufferedImage } from "../imaging/buffered-image";
import { ImageWorld } from "../photogrammetry/image-world";
import { Polygon } from "@turf/turf";
import { Point2D } from "../photogrammetry/warp";
import booleanIntersects from '@turf/boolean-intersects'
import { Rectangle } from "../shapes/rectangle";

export class TileserverImage {
  private tilePyramidDescriptor: TilePyramidDescriptor;
  public _cameraModel: CameraModel;

  static build(collectionId: string, timestamp: string, tileserverClient: TileserverClient, tileCacheService: TileCacheService): Observable<TileserverImage> {
    return tileCacheService.getMetadata(collectionId, timestamp).pipe(
      map(descriptor =>
        new TileserverImage(descriptor, tileCacheService)
      ));
  }

  constructor(tilePyramidDescriptor: TilePyramidDescriptor, private cacheService: TileCacheService) {
    this.tilePyramidDescriptor = tilePyramidDescriptor
    var bbox = this.tilePyramidDescriptor.boundingBox;
    this._cameraModel = new FourCornerBasedCameraModel(
      this.tilePyramidDescriptor.width,
      this.tilePyramidDescriptor.height,
      [new Coordinate(bbox[0], bbox[3], 0),
       new Coordinate(bbox[2], bbox[3], 0),
       new Coordinate(bbox[2], bbox[1], 0),
       new Coordinate(bbox[0], bbox[1], 0)],
      new Point2D(0,0)
    )
  }

  public get collectionId(): string {
    return this.tilePyramidDescriptor.name.split(":")[0]
  }

  public get timestamp(): string {
    return this.tilePyramidDescriptor.name.split(":")[1]
  }


  getTopTile(): TileRef {
    return new TileRef(this, this.getMaxRLevel(), 0, 0, 0);
  }

  getMaxRLevel(): number {
    return this.tilePyramidDescriptor.maxRLevel;
  }


  getName(): string {
    return this.tilePyramidDescriptor.name;
  }

  getNumBands(): number {
    return this.tilePyramidDescriptor.metadata.NBANDS;
  }

  getR0ImageWidth(): number {
    return this.tilePyramidDescriptor.width;
  }

  getR0ImageHeight(): number {
    return this.tilePyramidDescriptor.height;
  }

  getTileWidth(): number {
    return this.tilePyramidDescriptor.tileWidth;
  }

  getTileHeight(): number {
    return this.tilePyramidDescriptor.tileHeight;
  }
  

  getBoundingBox(): number[] {
    return this.tilePyramidDescriptor.boundingBox
  }

  public get cameraModel(): CameraModel {
    return this._cameraModel;
  }

  getTileserverTile(tileRef: TileRef): Observable<BufferedImage> {
    const numBands = this.getNumBands()
    var bufferedImageBands: Observable<BufferedImage>[] = [];

    for (var i = 0; i < numBands; i++) {
      bufferedImageBands.push(this.getTileserverTileForBand(tileRef.getForBand(i)));
    }

    return forkJoin(bufferedImageBands).pipe(
      map(imageBands => {
        if(numBands >= 3) {
          return this.mergeBands([imageBands[0], imageBands[1], imageBands[2]]);
        } else {
          return this.mergeBands([imageBands[0], imageBands[0], imageBands[0]])
        }
      })
    )
  }

  private getTileserverTileForBand(tileRef: TileRef): Observable<BufferedImage> {
    return this.cacheService.getTile(tileRef);
  }

  private mergeBands(bands: BufferedImage[]): BufferedImage {
    if(bands.length!=3) {
      console.error("Only supports 3 bands at a time")
    }
    var bufferSize = bands[0].imageData.length * 4
    var buffer = new Uint8Array(bufferSize);
    for(var i=0; i<bufferSize;i+=4) {
        buffer[i] = bands[0].imageData[Math.round(i/4)]
        buffer[i+1] = bands[1].imageData[Math.round(i/4)]
        buffer[i+2] = bands[2].imageData[Math.round(i/4)]
        buffer[i+3] = 255
    }

    return BufferedImage.cloneWithNewBuffer(bands[0], buffer);
  }

  isVisible(tileRef: TileRef, imageWorld: ImageWorld, geodeticViewport: Polygon, targetRset: number): boolean {
    var geodeticTile = imageWorld.getGeodeticTile(tileRef)
    return booleanIntersects(geodeticTile, geodeticViewport);
  }

  /**
   * Gets the image data for all tiles to render at the target rset that are decendents of this tile, or this tile itself.
   * It is intended to call this function with the top of the image pyramid to recursively search for tiles of the pyramid
   * that are inside the projectedViewport at the target rset.
   */
  getTilesToRender(targetRset: number, tile: TileRef, imageWorld: ImageWorld, geodeticViewport: Polygon): TileRef[] {
    var currentRset: number = tile.rset;
    var tilesToRender: TileRef[] = [];
    var nextRset = currentRset - 1;

    var isVisible = this.isVisible(tile, imageWorld, geodeticViewport, targetRset)

    if (isVisible) {
      if (nextRset >= targetRset) {
        var subTiles = tile.createSubTiles();
        subTiles.forEach(subtile => {
          tilesToRender.push(...this.getTilesToRender(targetRset, subtile, imageWorld, geodeticViewport))
        });
        return tilesToRender;
      }
      if(tile.rset == targetRset) {
        return [tile]
      }
    }
    return []
  }

  getR0ImageRectangle(): Rectangle {
    return new Rectangle(0, 0, this.getR0ImageWidth(), this.getR0ImageHeight());
  }

  getR0ImageBounds(): Point2D[] {
    var r0Image: Rectangle = this.getR0ImageRectangle();
    return [
      new Point2D(r0Image.getMinX(),   r0Image.getMinY()  ),
      new Point2D(r0Image.getMaxX()-1, r0Image.getMinY()  ),
      new Point2D(r0Image.getMaxX()-1, r0Image.getMaxY()-1),
      new Point2D(r0Image.getMinX(),   r0Image.getMaxY()-1),
      new Point2D(r0Image.getMinX(),   r0Image.getMinY()  )
    ]
  }

}