import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TilePyramidDescriptor } from './tile-pyramid-descriptor';
import { TileRef } from './tile-ref';
import { retryBackoff } from 'backoff-rxjs';

@Injectable({
  providedIn: 'root'
})
export class TileserverClient {

  private tileserverUrl = 'https://tileserver.leidoslabs.com';
  private apiKey = 'sAWFuNz3RmanpIhHazTdo8hwT7bKhWPAa5MYcBbX'
  private INIT_INTERVAL_MS = 1
  private retryCodes = [408, 429, 502, 503, 504]

  constructor(private http: HttpClient) { }

  getMetadata(collectionId: string, timestamp: string): Observable<TilePyramidDescriptor> {
    var metadata_url = `${this.tileserverUrl}/tileserver/${collectionId}/${timestamp}/metadata.json`
    return this.http.get<TilePyramidDescriptor>(metadata_url, { headers: { 'x-api-key': this.apiKey } }).pipe(
      retryBackoff({
        initialInterval: this.INIT_INTERVAL_MS,
        shouldRetry: (error) => {
          return this.retryCodes.includes(error.status)
        },
        backoffDelay: (iteration, initialInterval) => Math.pow(2, iteration) * initialInterval
      })
    )
  }

  getTile(tileRef: TileRef): Observable<ArrayBuffer> {
    var tile_url = `${this.tileserverUrl}/tileserver/${tileRef.getTileserverPath()}.png`
    return this.http.get(tile_url, {
      responseType: "arraybuffer",
      headers: { 'x-api-key': this.apiKey }
    }).pipe(
      retryBackoff({
        initialInterval: this.INIT_INTERVAL_MS,
        shouldRetry: (error) => {
          return this.retryCodes.includes(error.status)
        },
        backoffDelay: (iteration, initialInterval) => Math.pow(2, iteration) * initialInterval
      })
    )
  }
}