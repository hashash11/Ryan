import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { CesiumDirective } from './cesium.directive';
import { DBConfig, NgxIndexedDBModule } from 'ngx-indexed-db';

const dbConfig: DBConfig  = {
  name: 'ImageCacheDB',
  version: 2,
  objectStoresMeta: [{
    store: 'imagery',
    storeConfig: { keyPath: 'id', autoIncrement: true },
    storeSchema: [
      { name: 'tileKey', keypath: 'tileKey', options: { unique: true } }
    ]
  },{
    store: 'metadata',
    storeConfig: { keyPath: 'id', autoIncrement: true },
    storeSchema: [
      { name: 'imageId', keypath: 'imageId', options: { unique: true } }
    ]
  }]
};

@NgModule({
  declarations: [
    AppComponent,
    CesiumDirective
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    NgxIndexedDBModule.forRoot(dbConfig)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
