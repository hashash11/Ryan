import { polygon, featureCollection, Feature, FeatureCollection } from '@turf/turf'
import booleanIntersects from '@turf/boolean-intersects'
import rawCatalog from './catalog.json'

export default class Catalog {
    private static catalog: Feature[];
    private constructor() { }

    public static getCatalog(): Feature[] {
        if (!Catalog.catalog) {
            Catalog.catalog = rawCatalog.map(entry => {
                // TODO In case the bounds of the image are not in bbox format, they should be converted to a polygon representing a bbox.
                return polygon(entry.bounds.coordinates, { 'name': entry.name, 'imageLink': entry.imageLink, 'date': entry.date, 'edhIdentifier': entry.edhIdentifier });
            });
        }
        return Catalog.catalog;
    }

    static intersectingImagesCollection(tileBoundingBox: Feature): FeatureCollection {
        const imagesIntersected: Feature[] = [];

        if (Catalog.catalog) {
            for (const feature of Catalog.catalog) {
                const intersects = booleanIntersects(tileBoundingBox, feature);
                if (intersects) {
                    imagesIntersected.push(feature);
                }
            }
        }

        return featureCollection(imagesIntersected);
    }
}