import { Matrix4 } from "@math.gl/core";

export interface TileRenderInfo {
    offset: number,
    size: number,
    width: number,
    height: number,
    vertices: number[],
    textureQuad: number[],
    mvpMat: Matrix4
}

export interface MercatorTileRenderRequest {
    id: number;
    draw: boolean;
    canvas: any;
    imageData: Uint8Array;
    tileRenderInfo: TileRenderInfo[];
}