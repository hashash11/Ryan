import { expose, Transfer } from 'threads/worker';

expose(
  function drawTile(data: any) {

    var shaders = {
      vert:
        `
      attribute vec3 a_position;
      attribute vec2 a_texcoord;
  
      uniform mat4 u_mvpMat;
  
      varying vec2 v_texcoord;
      
      void main() {
          gl_Position = u_mvpMat * vec4(a_position, 1.0);
          v_texcoord = a_texcoord;
      }
      `,
      frag:
        `
      precision mediump float;
  
      varying vec2 v_texcoord;
  
      uniform sampler2D u_texture;
      
      void main()
      {
          gl_FragColor = texture2D(u_texture, v_texcoord);
      }
      `
    }

    function loadShader(gl: WebGL2RenderingContext, type: number, source: string): WebGLShader | null {
      var shader = gl.createShader(type);
      if (shader != null) {
        try {
          gl.shaderSource(shader, source);
          gl.compileShader(shader);
          return shader;
        } catch (ex) {
          console.error("Error compiling shader\n" + ex);
          return null;
        }
      } else {
        console.error("Error in gl.createShader())")
        return null;
      }
    }

    function createShaderProgram(gl: WebGL2RenderingContext, shaderGLSL: { vert: string, frag: string }) {

      var vertexShader = loadShader(gl, gl.VERTEX_SHADER, shaderGLSL.vert);
      var fragmentShader = loadShader(gl, gl.FRAGMENT_SHADER, shaderGLSL.frag);

      if (!vertexShader || !fragmentShader) {
        return null;
      }

      var program = gl.createProgram();

      if (!program) {
        console.error("error in gl.createProgram()")
        return null;
      }

      gl.attachShader(program, vertexShader);
      gl.attachShader(program, fragmentShader);
      gl.linkProgram(program);
      return program;
    }

    function initShaders(gl: WebGL2RenderingContext, shaderGLSL: { vert: string, frag: string }): WebGLProgram | null {
      var program = createShaderProgram(gl, shaderGLSL);
      if (program) {
        gl.useProgram(program);
        return program;
      } else {
        return null;
      }

    }

    function drawTransparentTile(gl: WebGL2RenderingContext): void {
      if (gl != null) {
        gl.clearColor(0., 0., 0., 0.);
        gl.clear(gl.COLOR_BUFFER_BIT);
      }
    }

    var offscreen = data['canvas'];
    var imageInfo: any[] = data['tileRenderInfo'];
    const gl: WebGL2RenderingContext = offscreen.getContext("webgl2");

    try {
      if (!gl) {
        throw "failed creating a webgl context (generator.worker.ts)"
      }

      if (!data['draw']) { // no image, return a transparent tile
        drawTransparentTile(gl);

        var blankTile = offscreen.transferToImageBitmap()
        return Transfer({
          "bitmap": blankTile,
          "id": data['id'],
          "success": true,
          "failure_message": ""
        }, [blankTile])
      }

      var program = initShaders(gl, shaders);
      if (!program) {
        throw "Failure initializing shader program";
      }
      // gl.clearColor(0.3,0.5,0.7,0.5);
      gl.clear(gl.COLOR_BUFFER_BIT);

      var allImageData: Uint8Array = data['imageData']
      imageInfo.forEach(image => {

        var vertexBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(image.vertices), gl.DYNAMIC_DRAW);

        var texcoordBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, texcoordBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(image.textureQuad), gl.DYNAMIC_DRAW);

        var tex = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, tex);
        // if image length not expected to be multiple of 4 then set
        // gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, image.width, image.height, 0, gl.RGBA, gl.UNSIGNED_BYTE, allImageData.slice(image.offset, image.offset + image.size), 0);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

        gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
        var vertexLocation = gl.getAttribLocation(program!, "a_position")
        var vertexElementSize = 3
        gl.vertexAttribPointer(vertexLocation, vertexElementSize, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(vertexLocation);

        gl.bindBuffer(gl.ARRAY_BUFFER, texcoordBuffer);
        var texCoordLocation = gl.getAttribLocation(program!, "a_texcoord")
        var textureElementSize = 2
        gl.vertexAttribPointer(texCoordLocation, textureElementSize, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(texCoordLocation);
        gl.uniformMatrix4fv(gl.getUniformLocation(program!, "u_mvpMat"), false, new Float32Array(image.mvpMat))

        // Tell the shader to get the texture from texture unit 0
        gl.uniform1i(gl.getUniformLocation(program!, "u_texture"), 0);

        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

      })

      var renderedTile: ImageBitmap = offscreen.transferToImageBitmap();

      return Transfer({
        "bitmap": renderedTile,
        "id": data['id'],
        "success": true,
        "failure_message": ""
      }, [renderedTile])

    } catch (error: any) {
      console.error(error)
      return {
        "id": data['id'],
        "success": false,
        "failure_message": "" + error
      }
    }

  }
)