/// <reference lib="webworker" />

addEventListener('message', ({ data }) => {

  var width = data['width'];
  var height = data['height'];

  var offscreen = data['canvas']

  const gl = offscreen.getContext("webgl");

  if (gl!=null) {
    // set the canvas color (demo to prove we are actually drawing)
    gl.clearColor(0.5, 0.1, 0.5, 3);
    gl.clear(gl.COLOR_BUFFER_BIT);
  } else {
    console.error("failed creating a webgl context (generator.worker.ts)")
  }

  var bitmap = offscreen.transferToImageBitmap();

  var response = {
    "bitmap": bitmap,
    "id": data['id'],
    "success": true,
    "failure_message": ""
  }

  postMessage(response, [response.bitmap]);
});
