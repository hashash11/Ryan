import { polygon, Polygon } from "@turf/turf";
import { BufferedImage } from "../imaging/buffered-image";
import { Coordinate } from "../photogrammetry/camera-model";
import { Point2D } from "../photogrammetry/warp";
import { ImageScale } from "../photogrammetry/image-scale";
import { Rectangle } from "../shapes/rectangle";
import { TileserverImage } from "./tileserver-image";
import { Observable } from "rxjs";

interface Dimension {
    width: number,
    height: number
}

export class TileRef {
    public image: TileserverImage;
    public x: number;
    public y: number;
    public rset: number;
    public band: number;
    private nextRsetRowsCols: Dimension;

    constructor(image: TileserverImage, rset: number, x: number, y: number, band: number) {
        this.image = image;
        this.x = x;
        this.y = y;
        this.rset = rset;
        this.band = band;        
        this.nextRsetRowsCols = this.getRowsAndColumnsForRset(rset-1);
    }

    getWidth() {
        return this.image.getTileWidth();
    }

    getHeight() {
        return this.image.getTileHeight();
    }

    getRowsAndColumnsForRset(rset: number): Dimension {
        if(rset<0) {
           return {width: 0, height: 0}
        }
        var rsetFactor = Math.pow(2.0, rset);
        return {
            width: Math.ceil(this.image.getR0ImageWidth() / (rsetFactor * this.getWidth())),
            height: Math.ceil(this.image.getR0ImageHeight() / (rsetFactor * this.getHeight()))
        }
    }

    getForBand(band: number): TileRef {
        return new TileRef(this.image, this.rset, this.x, this.y, band);
    }

    getImageName(): string {
        return this.image.getName()
    }

    getCacheKey(): string {
        return this.getImageName() + ":" + this.rset + ":" + this.x + ":" + this.y + ":" + this.band
    }
    
    getTileserverPath(): string {
        // @ts-ignore we are using es2022 but string.replaceAll still complains in vscode
        return this.getCacheKey().replaceAll(":","/");
    }

    createSubTiles(): TileRef[] {
        var subtiles: TileRef[] = []
        if (this.rset > 0) {
            var nextRset = this.rset - 1;
            for(var row=this.y*2;row<Math.min(this.y*2+2,this.nextRsetRowsCols.height);++row) {
                for(var col=this.x*2;col<Math.min(this.x*2+2,this.nextRsetRowsCols.width);++col) {
                    subtiles.push(new TileRef(this.image, nextRset, col, row, this.band));
                }
            }
        }
        return subtiles;
    }

    getFullR0RectInImageSpace(): Rectangle {
        var tileScale: ImageScale = ImageScale.forRset(this.rset);
        var tileDim: Point2D = new Point2D(this.getWidth(), this.getHeight());
        var tileDimR0: Point2D = tileScale.scaleUpToR0(tileDim);
        var tileWidth = Math.round(tileDimR0.getX());
        var tileHeight = Math.round(tileDimR0.getY());
        var fullTile = new Rectangle(this.x * tileWidth, this.y*tileHeight, tileWidth, tileHeight);
        return fullTile
    }

    getR0RectInImageSpace(): Rectangle {
        var imageRectangle = this.image.getR0ImageRectangle();
        return imageRectangle.intersection(this.getFullR0RectInImageSpace())
    }

    getImageSpaceBounds(): Polygon {

        var r0Rect: Rectangle = this.getR0RectInImageSpace();

        var ll: Coordinate = new Coordinate(r0Rect.getMinX(), r0Rect.getMinY(), 0.0);
        var lr: Coordinate = new Coordinate(r0Rect.getMaxX()-1, r0Rect.getMinY(), 0.0);
        var ur: Coordinate = new Coordinate(r0Rect.getMaxX()-1, r0Rect.getMaxY()-1, 0.0);
        var ul: Coordinate = new Coordinate(r0Rect.getMinX(), r0Rect.getMaxY()-1, 0.0);

        // order matters
        return polygon([[[ll.x, ll.y], [lr.x, lr.y], [ur.x, ur.y], [ul.x, ul.y], [ll.x, ll.y]]]).geometry

    }

    getBufferedTile(): Observable<BufferedImage> {
        return this.image.getTileserverTile(this);
    }
}